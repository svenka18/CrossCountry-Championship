# -*- coding: utf-8 -*-
"""
Created on Sat Jul 15 18:03:40 2017

@author: suraj
"""
from selenium import webdriver
from selenium.webdriver.common.keys import Keys
from selenium.common.exceptions import WebDriverException, NoSuchElementException

def run():
    try:
        profile = webdriver.FirefoxProfile()
        #adblockfile = r'./adblock_plus-2.7.3-sm+tb+fx+an.xpi'
        #adblockfile = r'./uBlock0.firefox.xpi'
        #profile.add_extension(extension=adblockfile)
        #profile.set_preference('extensions.ublock0.currentVersion', '1.7.6')
        driver = webdriver.Firefox(firefox_profile=profile)
        return driver
    except Exception as e:
        print('Inside the scraper driver getter')
        print(e)
if __name__ == '__main__':
    run()