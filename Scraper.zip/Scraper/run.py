from athleteScraper import MileSplitNavigator
import time
from datetime import datetime
from datetime import timedelta

def run():
    with open('regions.txt', encoding='utf8') as f:
        links = f.read().split('\n')
    for link in links:
        lctime = datetime.today()
        if(lctime.hour > 6):
            future = datetime(lctime.year,lctime.month,lctime.day + 1,0,0)
            print('[*] sleeping till ' + str(future))
            print('[*] sleeping ' + str((future - lctime).total_seconds()) + ' seconds')
            time.sleep((future - lctime).total_seconds())
        if link[0] == '#':
            continue
        navigator = MileSplitNavigator('dhague', 'mit2000', link, 'output.csv', 'runners.txt','log.txt')
        navigator.scrapePage()
        while navigator.nextPage():
            navigator.scrapePage()
            time.sleep(2)
        navigator.close()
    
if __name__ == '__main__':
    run()
