from selenium import webdriver
from selenium.webdriver.common.keys import Keys
from selenium.common.exceptions import WebDriverException, NoSuchElementException
from datetime import datetime
from datetime import timedelta
import time, os, merge

page = ''

def getDriver():
    try:
        #profile = webdriver.FirefoxProfile()
        #adblockfile = r'C:/Users/suraj/Scraper/adblock_plus-2.7.3-sm+tb+fx+an.xpi'
        #adblockfile = r'./uBlock0.firefox.xpi'
        #profile.add_extension(extension='adblock_plus-2.7.3-sm+tb+fx+an.xpi')
        #profile.set_preference('extensions.adblockplus.currentVersion', '2.7.3')
        #driver = webdriver.Firefox(firefox_profile=profile)        
        driver_options = webdriver.ChromeOptions()
        driver_options.add_extension(r'C:\Users\suraj\Downloads\AdBlock_v.crx')
        driver = webdriver.Chrome(chrome_options = driver_options)                
        return driver
    except Exception as e:
        print('Inside the scraper driver getter')
        print(e)
    
def linkedResults(driver):
    links = driver.find_elements_by_xpath("//table[@class='meetResultsList']/tbody/tr/td/a")
    limit = len(links)
    j = 0
    scroll = 0
    while j < limit:
        try:
            driver.execute_script("window.scrollTo(0," + str(scroll) + ");")
            links[j].click()
            time.sleep(5)
            checkPageType(driver)
            driver.back()
            time.sleep(5)
            links = driver.find_elements_by_xpath("//table[@class='meetResultsList']/tbody/tr/td/a")
            j += 1
            scroll += 20
        except Exception as e:
            print('[-] error ' + str(e))
            goToResultsPage(driver)
            break
            
    
def milesplitLogin(driver, login, password):
    print('[*] logging in')
    driver.get('https://nc.milesplit.com')
    element = driver.find_element_by_xpath("//a[@href='#account']")
    element.click()
    element = driver.find_element_by_xpath("//a[@href='/login?next=http%3A%2F%2Fnc.milesplit.com%2F&site=34']")
    element.click()
    time.sleep(5)
    element = driver.find_element_by_name("username")
    element.send_keys(login)
    element = driver.find_element_by_name("password")
    element.send_keys(password)
    element = driver.find_element_by_class_name("btn-login")
    element.click()
    time.sleep(5)
    print('[+] login complete')
    return driver
    
def goToResultsPage(driver):
    global page
    print('[*] going to results page: ' + page)
    driver.get(page)
def setResultsPage(name):
    global page
    page = name
    file = open('currentUrl.txt','w', encoding='utf8')
    file.write(name)
    file.close()
    
def getResultsPages(driver):
    print('[*] getting results links')
    elements = driver.find_elements_by_xpath("//td[@class='name']/a")
    print('[+] got results links ' + str(len(elements)) + ' found') 
    return elements
    
def scrapePage(driver):
    fileName = driver.title.replace(' ', '').replace('\t', '')+".csv"
    fileName = fileName.replace('/', '')
    if os.path.exists('./Results/' + fileName):
        file = open('./Results/' + fileName, encoding='utf8')
        text = file.read()
        file.close()
        if len(text) > 0:
            print('[*] ' + fileName + ' already exists skipping. . .')
            return
    print('[*] scraping page: ' + driver.current_url)
    f = open('./Results/' + fileName, 'w', encoding='utf8')
    date = driver.find_element_by_xpath('//time')
    name = driver.find_element_by_class_name('meetName')
    venue = driver.find_element_by_class_name('venueName')
    f.write(name.text.replace(',','') + '\n')
    f.write(date.text.replace(',','') + '\n')
    f.write(venue.text.replace(',', '') + '\n')
    tables = driver.find_elements_by_xpath("//div[@id='resultsList']/table/thead/tr[1]")
    for i in range(1, len(tables) + 1):
        f.write(tables[i - 1].text.replace(',', '') + '\n')
        header = driver.find_elements_by_xpath("//div[@id='resultsList']/table/thead[" + str(i) + "]/tr[2]/th")
        hd = []
        for data in header:
            hd.append(data.text.replace(',',''))
        f.write(','.join(hd) + '\n')
        rows = driver.find_elements_by_xpath("//div[@id='resultsList']/table/tbody[" + str(i) + "]/tr")
        for j in range(1, len(rows) + 1):
            td = driver.find_elements_by_xpath("//div[@id='resultsList']/table/tbody[" + str(i) + "]/tr[" + str(j) + "]/td")
            for data in td:
                f.write(str(data.text.replace(',','')) + ",")
            f.write('\n')
    print('[+] writing page to: ' + fileName)
    f.close()

    
 
def scrapeRaw(driver):
    fileName = driver.title.replace(' ', '').replace('\t', '')+".csv"
    fileName = fileName.replace('/', '')
    if os.path.exists('./Results/' + fileName):
        file = open('./Results/' + fileName, encoding='utf8')
        text = file.read()
        file.close()
        if len(text) > 0:
            print(fileName + ' already exists skipping. . .')
            return
    print('[*] scraping page: ' + driver.current_url)
    element = driver.find_element_by_xpath("//div[@id='meetResultsBody']/pre")
    text = element.text.replace(',','')
    f = open('./Results/' + fileName,'w', encoding='utf8')
    date = driver.find_element_by_xpath('//time')
    name = driver.find_element_by_class_name('meetName')
    f.write(name.text.replace(',','') + '\n')
    f.write(date.text.replace(',','') + '\n')
    print('[+] writing page to: ' + fileName)
    f.close()
    formatText(text, fileName)

def formatText(text, fileName):
    f = open('./Results/' + fileName,'a', encoding='utf8')
    lines = text.split('\n')
    state = 0
    cols = []
    stateCount = 0
    try:
        for i in range(len(lines)):
            if state == 0:
                if(lines[i] == '=' * len(lines[i]) and lines[i][0] == '='):
                    f.write(lines[i - 1].strip().replace(',','') + '\n')
                    cols = getColumns(lines[i + 1])
                    f.write(formatLine(lines[i + 1], cols) + '\n')
                    state = 1
            elif state == 1:
                stateCount += 1
                if(stateCount == 2):
                    stateCount = 0
                    state = 3
            elif state == 3:
                    if cols[len(cols) - 1] < len(lines[i]):
                        cols = getColumns(lines[i])
                        f.write(formatLine(lines[i], cols) + '\n')
                    elif 'Finals' in lines[i]:
                        state = 3
                    else:
                        state = 0
    except:
        pass
    f.close()

def formatLine(line, cols):
    parts = []
    for i in range(len(cols)):
        if(not i == len(cols) - 1):
            parts.append(line[cols[i]:cols[i+1]].strip().replace(',',''))
        else:
            parts.append(line[cols[i]:].strip().replace(',',''))
    
    return ','.join(parts)
            
def getColumns(line):      
    columns = []
    state = 0
    for j in range(len(line)):
        if state == 0:
            if not line[j] == ' ':
                columns.append(j)
                state = 1
        elif(state == 1):
            if(len(line) > j + 1 and  line[j] == ' ' and line[j + 1] == ' ') or (len(columns) < 2 and line[j] == ' '):
                state = 0
    return columns
    
def checkPageType(driver):
    try:
        element = driver.find_element_by_xpath("//div[@id='content']/div/article/header/h2")
    except NoSuchElementException as e:
        element = driver.find_element_by_xpath("//div[@id='content']/div/section/header/h2")
    txt = element.text
    if ('Results' in txt and not 'Meet' in txt) or 'Finals' in txt or 'Open' in txt or 'Boys' in txt or 'Girls' in txt:
        if('(Raw)' in driver.title):
            scrapeRaw(driver)
        else:
            scrapePage(driver)
    elif txt == 'Meet Results':
        print('[*] found linked results')
        linkedResults(driver)
        
def main():
    driver = getDriver()
    milesplitLogin(driver, 'sdesai33', 'woodward135')
    pageFile = open("currentUrl.txt", encoding='utf8')
    setResultsPage(pageFile.read())
    pageFile.close()
    goToResultsPage(driver)
    while True:
        lctime = datetime.today()
        if(lctime.hour > 6):
            merge.main()
            future = datetime(lctime.year,lctime.month,lctime.day + 1,0,0)
            print('[*] sleeping till ' + str(future))
            time.sleep((future - lctime).total_seconds())
        pages = getResultsPages(driver)
        limit = len(pages)
        i = 0
        scroll = 0
        while i < limit:
            try:
                driver.execute_script("window.scrollTo(0," + str(scroll) + ");")
                pages[i].click()
                time.sleep(5)
                checkPageType(driver)
                print('completed page')
                goToResultsPage(driver)
                time.sleep(5)
                pages = getResultsPages(driver)
                i += 1
                scroll += 33
            except Exception as e:
                print('[-] error ' + str(e))
                i += 1
                scroll += 33
                goToResultsPage(driver)
                pages = getResultsPages(driver)
        print('[+] finished page going to next page')
        goToResultsPage(driver)
        element = driver.find_element_by_link_text("NEXT")
        element.click()
        setResultsPage(driver.current_url)
        
    return driver

if __name__ == '__main__':
    while True:
        try:
            main()
        except Exception as e:
            print('[-] error: ' + e)
            print('[*] restarting. . .')
