import os

def duplicateSearch(lst):
    print('[+] starting duplicate search')
    final = []
    while len(lst) > 0:
        a = lst.pop()
        if a == '':
            continue
        if not a in lst:
            final.append(a)
    return final
def writeFile(lst, fname):
    print('[+] writing file')
    if os.path.exists(fname):
        i = 0
        while os.path.exists(fname + str(i)):
            i += 1
        with open(fname + str(i) + '.csv', encoding='utf8') as f:
            f.write('\n'.join(lst))
        print('[+] wrote file to ' + fname + str(i) + '.csv')
    else:
        with open(fname + '.csv','w', encoding='utf8') as f:
            f.write('\n'.join(lst))
        print('[+] wrote file to ' + fname + '.csv')

def sort(lst):
    print('[+] starting sort')
    jump = []
    run = []
    for item in lst:
        a = item.split(',')
        if '-' in a[5]:
            jump.append(item)
        else:
            run.append(item)
    return run, jump

def timeToSec(time):
    if time.count(':') == 2:
        t = time.find(':')
        total = 60 * float(time[:t])
        s = time.find(':', t+1)
        total += float(time[t+1:s])
        total += float(time[s+1:]) / 100
        return str(total)
    elif time.count(':') == 1:
        t = time.find(':')
        total = 60 * float(time[:t])
        total += float(time[t + 1:])
        return str(total)
    elif time.count(':') == 0:
        return time

def convertRun(lst):
    print('[+] converting times to seconds')
    for i in range(len(lst)):
        t = lst[i].split(',')
        t[5] = timeToSec(t[5])            
        lst[i] = ','.join(t)
    return lst
def main():
    files = os.listdir('./Results')
    data = []
    print('[+] reading files')
    for file in files:
        with open('./Results/' + file, encoding='utf8') as f:
            data += f.read().split('\n')
    data = duplicateSearch(data)
    runners, jumpers = sort(data)
    writeFile(jumpers, 'jumpMerge')
    runners = convertRun(runners)
    writeFile(runners, 'runMerge')
    

if __name__ == '__main__':
    main()
