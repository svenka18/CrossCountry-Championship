from tkinter import *
from tkinter import messagebox
import time
from datetime import datetime
from datetime import timedelta
from athleteScraper import MileSplitNavigator

class Window(Frame):
    
    def __init__(self, title, geometry):
        self.root = Tk()
        self.root.geometry(geometry)
        Frame.__init__(self, self.root)
        self.root.title(title)
        mnuBar = Menu(self.root)
        mnuFile = Menu(mnuBar, tearoff=0)
        mnuFile.add_command(label='Exit', command=self.quit)
        mnuBar.add_cascade(label='File', menu=mnuFile)
        self.root.config(menu=mnuBar)
        self.pack(fill=BOTH, expand=True)
    def start(self):
        self.root.mainloop()
    def quit(self):
        self.root.destroy()
        
class MileSplitGUI(Window):
    def __init__(self):
        Window.__init__(self, 'Mile Split Scraper', '400x400')
        
        radioFrame = Frame(self)
        self.gender = IntVar()
        lblRadio = Label(radioFrame,text='Boys or Girls')
        lblRadio.grid(row=0,column=0)
        rdbtnGirls = Radiobutton(radioFrame, text='girls', variable=self.gender, value=1)
        rdbtnGirls.grid(row=1,column=0)
        rdbtnBoys = Radiobutton(radioFrame, text='boys', variable=self.gender, value=2)
        rdbtnBoys.grid(row=1,column=1)
        #
        radioFrame.pack()
        
        yearFrame=Frame(self)
        self.year = StringVar()
        lblYear = Label(yearFrame, text='enter year')
        lblYear.grid(row=0,column=0)
        txtYear = Entry(yearFrame, bd=5, textvariable=self.year)
        txtYear.grid(row=1,column=0)
        yearFrame.pack()
        
        regionsFrame = Frame(self)
        lblRegions = Label(regionsFrame, text='Select Regions')
        lblRegions.grid()
        btnSelectAll = Button(regionsFrame, text='Select All', command=self._selectAll)
        btnSelectAll.grid(row=0,column=1)
        regions = ['1A East','1A Mideast', '1A Midwest', '1A West','2A East','2A Mideast', '2A Midwest', '2A West','3A East','3A Mideast', '3A Midwest', '3A West','4A East','4A Mideast', '4A Midwest', '4A West', 'NCISAA 1A', 'NCISAA 1/2A','NCISAA 2A', 'NCISAA 3A']
        self.regionVars = []
        for i in range(len(regions)):
            self.regionVars.append(IntVar())
        self.chbxRegions = []
        for i in range(len(regions)):
            self.chbxRegions.append(Checkbutton(regionsFrame, text=regions[i],variable=self.regionVars[i]))
            self.chbxRegions[i].grid(row=i//4 + 1,column=i%4)
        regionsFrame.pack()
        
        eventFrame = Frame(self)
        self.event = IntVar()
        lblEvent = Label(eventFrame, text='select event')
        lblEvent.grid()
        rdbtn5k = Radiobutton(eventFrame, text='5k', variable=self.event, value=1)
        rdbtn5k.grid(row=1,column=0)
        rdbtn2Mile = Radiobutton(eventFrame, text='3200m', variable=self.event, value=2)
        rdbtn2Mile.grid(row=1,column=1)
        rdbtnMile = Radiobutton(eventFrame, text='1600m', variable=self.event, value=3)
        rdbtnMile.grid(row=2,column=0)
        rdbtn800 = Radiobutton(eventFrame, text='800m', variable=self.event, value=4)
        rdbtn800.grid(row=2, column=1)
        eventFrame.pack()
        
        self.btnRun = Button(self, text='Run',command=self._go)
        self.btnRun.pack()
        
        self.timeDelay = IntVar()
        chbxTimeDelay = Checkbutton(self, text='Time Delay', variable=self.timeDelay)
        chbxTimeDelay.pack()
        
    def _selectAll(self):
        for i in range(len(self.chbxRegions)):
            self.chbxRegions[i].select()
        
        
    def _makeLinks(self):
        print('[+] making links')
        start = 'http://nc.milesplit.com/rankings/events/high-school-'
        links = []
        if self.gender.get() == 1:
            start += 'girls'
        elif self.gender.get() == 2:
            start += 'boys'
        start += '/cross-country/'
        if self.event.get() == 1:
            start += '5000m?'
        elif self.event.get() == 2:
            start += '3200m?'
        elif self.event.get() == 3:
            start += '1600m?'
        elif self.event.get() == 4:
            start += '800m?'
        start += 'year=' + str(self.year.get())
        regions = ['874','875','876','877','898','899','900','901','921','922','923','924','945','946','947','958','3394','2185','3396','2186']
#        for i in range(len(regions)):
#            if self.regionVars[i].get() == 1:
#                links.append(start + '&league=' + regions[i])
        links.append(start)
        print('[+] finished making links')
        return links
        
    def _go(self):
        error = False
        try:
            year = int(self.year.get())
            if self.event.get() == 0:
                error = 'no event selected'
            if self.gender.get() == 0:
                error = 'no gender selected'
            oneSelected = False
            for i in range(len(self.regionVars)):
                if self.regionVars[i].get() == 1:
                    oneSelected = True
                    break
            if not oneSelected:
                error = 'no regions were selected'
        except:
            error = 'year is not in correct fromat. should only be digits'
        if error:
            messagebox.showinfo('Error!',error)
            return
        links = self._makeLinks()
        self.btnRun.config(state=DISABLED)
        total = 0
        navigator = MileSplitNavigator('dhague', 'mit2000', 'http://nc.milesplit.com', 'output.csv', 'runners.txt','log.txt')

        for link in links:
##            try:
            lctime = datetime.today()
            if(lctime.hour > 6 and self.timeDelay.get() == 1):
                future = datetime(lctime.year,lctime.month,lctime.day + 1,0,0)
                print('[*] sleeping till ' + str(future))
                print('[*] sleeping ' + str((future - lctime).total_seconds()) + ' seconds')
                time.sleep((future - lctime).total_seconds())
            if link[0] == '#':
                continue
            navigator.linksPage = link
            navigator.driver.get(link)
            total += navigator.scrapePage()
            while navigator.nextPage():
                try:
                    total += navigator.scrapePage()
                except Exception as e:                        
                    with open('log.txt', 'a', encoding='utf8') as f:
                        print('[-] ' + time.strftime('%H:%M.%S %m/%d/%Y') + ' error in navigator.scrapePage() ' + str(e) + navigator.driver.current_url)
                        f.write('[-] ' + time.strftime('%H:%M.%S %m/%d/%Y') + ' error in navigator.scrapePage() ' + str(e) + navigator.driver.current_url + '\n')
                    
                time.sleep(2)
##            except Exception as e:                        
##                with open('log.txt', 'a') as f:
##                    print('[-] ' + time.strftime('%H:%M.%S %m/%d/%Y') + ' error ' + str(type(e)) + str(e) + navigator.driver.current_url)
##                    f.write('[-] ' + time.strftime('%H:%M.%S %m/%d/%Y') + ' error ' + str(type(e)) + str(e) + navigator.driver.current_url + '\n')
        self.btnRun.config(state=NORMAL)
        messagebox.showinfo('Done', 'Scraped ' + str(total) + ' athletes')
        navigator.close()
        return True
def run():
    gui = MileSplitGUI()
    gui.start()
if __name__ == '__main__':
    run()
