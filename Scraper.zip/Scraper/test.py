from athleteScraper import MileSplitNagivator

def run():
    navigator = MileSplitNagivator('dhague', 'mit2000', 'http://nc.milesplit.com/rankings/events/high-school-boys/cross-country/5000m?year=2015', 'output.csv')
    while True:
        navigator.scrapePage()
        navigator.nextPage()
    
if __name__ == '__main__':
    run()