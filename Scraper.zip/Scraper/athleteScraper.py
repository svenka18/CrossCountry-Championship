from selenium import webdriver
import scraper
import time

""" the athlete class is a class for scraping all of the althetes results of off an althetes page """
class Athlete:
    """ initilize athlete class
        @param driver selenium.webdriver the firefox webdriver
        @return none
    """
    def __init__(self, driver):
        # wait to load the page
        limit = 0
        while not self.contians_element_by_class_name(driver, 'lname') and limit < 20:
            limit += 1
            time.sleep(.5)
        # read the last name
        self.lastName = driver.find_element_by_class_name('lname').text.replace(',','')
        # read first name
        if self.contians_element_by_class_name(driver, 'fname'):
            self.firstName = driver.find_element_by_class_name('fname').text.replace('"', '').replace(',','')
        else:
            self.firstName = ''
        # read high school
        if self.contians_element_by_class_name(driver, 'hs'):
            self.team = driver.find_element_by_class_name('hs').text.replace(',','')
        else:
            self.team = ''
        # read grade
        if self.contians_element_by_class_name(driver, 'grade'):
            self.year = driver.find_element_by_class_name('grade').text[9:]
        else:
            self.year = ''
        # get url for unique id
        url = driver.current_url
        self.number = url[url.rfind('/') + 1:]
        self.raceResults = {}
        table = driver.find_elements_by_xpath('//table[@class="performances"]')
        rows = driver.find_elements_by_xpath('//tr')
        # read all the results
        for i in range(len(rows)):
            # read header
            if self.contians_element_by_class_name(rows[i], 'event'):
                event = rows[i].find_element_by_class_name('event').text
                self.raceResults[event] = []
            # read result
            elif self.contians_element_by_class_name(rows[i], 'time'):
                self.raceResults[event].append(Race(rows[i].find_element_by_class_name('time').text, rows[i].find_element_by_class_name('meet').text.replace(',',''), rows[i].find_element_by_class_name('start').text.replace(',','')))

    """ if the element has an element
        @param driver selenium.webdriver firefox webdriver
        @param xpath str xpath to find
        @return boolean if the element exists
    """
    def contians_element_by_xpath(self, driver, xpath):
        try:
            driver.find_element_by_xpath(xpath)
            return True
        except:
            return False

    """ if the element has an element
        @param driver selenium.webdriver firefox webdriver
        @param className str class name to find
        @return boolean if the element exists
    """
    def contians_element_by_class_name(self, driver, className):
        try:
            driver.find_element_by_class_name(className)
            return True
        except:
            return False

    """ converts an athlete to a string for printing or writing
        @param none
        @return str of the athlete
    """
    def to_string(self):
        result = ''
        for key in self.raceResults.keys():
            for race in self.raceResults[key]:
                result += self.number + ',' + self.firstName + ',' + self.lastName + ',' + self.team + ',' + self.year + ',' + race.to_string() + ',' + str(key) + '\n'
        return result
""" race class is the results for a race """
class Race:
    """ create a race object
        @param str time the race time
        @param str meet the meet's name
        @param str date the date of the meet
    """
    def __init__(self,time, meet, date):
        self.date = date
        self.time = time
        self.meet = meet

    """ turn a race into a string 
        @param none
        @return str the race in string format
    """
    def to_string(self):
        return self.time+','+self.date+','+self.meet

class MileSplitNavigator:
    """ create a milesplit navigator object
        @param login str the username for milesplit to login withj
        @param password str the password to log in with
        @param linksPage a page with all of the links 
        @param outFile the file to write the results to
        @param shortTale the list of all the athletes scraped
        @param log the log file to write to
        @return none
    """
    def __init__(self,login, password, linksPage, outFile, shortTable, log):
        self.log = log
        try:
            print ('[+] got to MileSplitNavigator')      
            print ('login creds are')      
            print (login + ' ' + password)      
            self.driver = scraper.getDriver()
        except Exception as e:
            with open(log, 'a', encoding='utf8') as f:
                print('[-] ' + time.strftime('%H:%M.%S %m/%d/%Y') + 'start up error')
                
                print(e)
                
                f.write('[-] ' + time.strftime('%H:%M.%S %m/%d/%Y') + 'start up error\n')
                
        try:
            scraper.milesplitLogin(self.driver, login, password)
            with open(log, 'a', encoding='utf8') as f:
                f.write('[+] ' + time.strftime('%H:%M.%S %m/%d/%Y') + ' logged in\n')
        except Exception as e:
            with open(log, 'a', encoding='utf8') as f:
                f.write('[-] ' + time.strftime('%H:%M.%S %m/%d/%Y') + 'log in failed\n')
        self.linksPage = linksPage
        self.outFile = outFile
        try:
            self.driver.get(linksPage)
        except Exception as e:
            with open(log, 'a', encoding='utf8') as f:
                f.write('[-] could not get to ' + linksPage + '\n\t error:' + str(e) + '\n')
        self.athletesList = []
        self.shortTable = shortTable
        self.numScraped = 0

    """ scrapes an athletes page
        @param none
        @return int the number of events scraped
    """
    def scrapePage(self):
        count = 0
        end = True
        while end and count < 20:
            try:
                # see if the page loaded
                links = self.driver.find_elements_by_xpath('//div[@class="athlete"]/a')
                end = False
            except:
                if count == 10:
                    self.driver.get(self.driver.current_url) #reload page
                time.sleep(.5)
                count += 1
        # report error
        if count >= 20:
            with open(self.log, 'a', encoding='utf8') as f:
                print('[-] ' + time.strftime('%H:%M.%S %m/%d/%Y') + ' error on page ' + self.driver.current_url)
                f.write('[-] ' + time.strftime('%H:%M.%S %m/%d/%Y') + ' error on page ' + self.driver.current_url + '\n')
        scroll = 0
        # for all of the links on the page
        for i in range(len(links)):
            try:
                #scroll down
                self.driver.execute_script("window.scrollTo(0," + str(scroll) + ");")
            except:
                # report error
                with open(log, 'a', encoding='utf8') as f:
                    print('[-] ' + time.strftime('%H:%M.%S %m/%d/%Y') + 'scroll error' + self.driver.current_url)
                    f.write('[-] ' + time.strftime('%H:%M.%S %m/%d/%Y') + 'scroll error' + self.driver.current_url + '\n')
            try:
                url = links[i].get_attribute('href')
            except:
                # report error
                print('[-] ' + time.strftime('%H:%M.%S %m/%d/%Y') + ' count not get attribute href from ' + links[i].text + ' @ ' + self.driver.current_url)
                with open(log, 'a', encoding='utf8') as f:
                        f.write('[-] ' + time.strftime('%H:%M.%S %m/%d/%Y') + ' count not get attribute href from ' + links[i].text + ' @ ' + self.driver.current_url + '\n')
            try:
                # get id number
                number = url[url.rfind('/') + 1:]
                # check to see if athlete has been scraped
                with open(self.shortTable, 'r+', encoding='utf8') as f:
                    numbers = f.read().split('\n')
                    numbers = numbers[:len(numbers) - 1]
                    skip = not number in numbers
                    if skip:
                        f.write(str(number) + '\n')
                    else:
                        scroll += 60
                        continue
            except Exception as e:
                # report error
                print('[-] '  + time.strftime('%H:%M.%S %m/%d/%Y') +  str(e) + str(type(e)))
                with open('log.txt', 'a', encoding='utf8') as f:
                        f.write('[-] '  + time.strftime('%H:%M.%S %m/%d/%Y') +  str(e) + str(type(e)))
                scroll += 60
                skip = False
            if skip:
                links[i].click()
                with open(self.outFile, 'a', encoding='utf8') as f:
                    try:
                        # scrape athletes results
                        a = Athlete(self.driver)
                        f.write(a.to_string())
                        self.numScraped += 1
                        print('[+] Athletes Scraped ' + str(self.numScraped), end='\r')
                    except Exception as e:
                        # try and scrape althele again
                        try:
                            with open(self.log,'a', encoding='utf8') as f:
                                print('[-] ' + time.strftime('%H:%M.%S %m/%d/%Y') + ' error refreshing ' + self.driver.current_url)
                                f.write('[-] ' + time.strftime('%H:%M.%S %m/%d/%Y') + ' error refreshing ' + self.driver.current_url + '\n')
                            driver.get(self.driver.current_url)
                            a = Athlete(self.driver)
                            f.write(a.to_string())
                            self.numScraped += 1
                            print('[+] Athletes Scraped ' + str(self.numScraped), end='\r')
                        except:
                            # unable to scrape althele
                            print('[-] unable to scrape athlete at ' + self.driver.current_url + '\n')
                            with open(self.log,'a', encoding='utf8') as f:
                                f.write('[-] ' + time.strftime('%H:%M.%S %m/%d/%Y') + ' unable to scrape athlete at ' + self.driver.current_url +'\n')
                self.driver.get(self.linksPage)
                #self.driver.back() # doesn't work
                links = self.driver.find_elements_by_xpath('//div[@class="athlete"]/a')
                count = 0
                # wait while page loads
                while len(links) == 0 and count < 20:
                    links = self.driver.find_elements_by_xpath('//div[@class="athlete"]/a')
                    count += 1
                    time.sleep(.1)
                # error if page doesn't load
                if count == 20:
                    print(len(links), i, self.driver.current_url)
                    raise Exception("Couldn't scrape links")
            # scroll down
            scroll += 60
        # report finished page
        with open(self.log, 'a', encoding='utf8') as f:
            print('[+] ' + time.strftime('%H:%M.%S %m/%d/%Y') + ' finished page: ' + self.driver.current_url)
            f.write('[+] ' + time.strftime('%H:%M.%S %m/%d/%Y') + ' finished page: ' + self.driver.current_url + '\n')
        return self.numScraped

    """ go to next page
        @param none
        @return True on success, False otherwise
    """
    def nextPage(self):
        try:
            el = self.driver.find_element_by_class_name('next')
            el.click()
            limit = 0
            while self.driver.current_url == self.linksPage and limit < 20:
                time.sleep(.5)
                limit += 1
            self.linksPage = self.driver.current_url
            if limit == 20:
                return False
            return True
        except:
            return False

    """ closes the driver
        @param none
        @return none
    """
    def close(self):
        print('[+] closing')
        self.driver.close()
